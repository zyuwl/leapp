from leapp.dialogs import test
test()
