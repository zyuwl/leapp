from leapp.topics import Topic


class WorkflowApiTopic(Topic):
    name = 'workflow_api_topic'
