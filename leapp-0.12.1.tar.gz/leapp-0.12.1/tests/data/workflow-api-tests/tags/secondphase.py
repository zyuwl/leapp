from leapp.tags import Tag


class SecondPhaseTag(Tag):
    name = 'second_phase'
