from leapp.tags import Tag


class WorkflowApiTestWorkflowTag(Tag):
    name = 'workflow_api_test_workflow'
