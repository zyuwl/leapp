from leapp.tags import Tag


class FirstPhaseTag(Tag):
    name = 'first_phase'
