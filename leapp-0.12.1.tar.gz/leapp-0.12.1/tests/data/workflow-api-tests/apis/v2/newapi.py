from leapp.workflows.api import WorkflowAPI

class NewAPI(WorkflowAPI):
    def fun(self):
        return 'NewAPI.fun'
