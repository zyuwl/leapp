from leapp.models import Model, fields
from leapp.topics import WorkflowApiTopic


class DepCheck3(Model):
    """ Empty model for test purposes """
    topic = WorkflowApiTopic
