from leapp.models import Model, fields
from leapp.topics import WorkflowApiTopic


class DepCheck2(Model):
    """ Empty model for test purposes """
    topic = WorkflowApiTopic
