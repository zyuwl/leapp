from leapp.topics import Topic


class DeprecationTopic(Topic):
    name = 'deprecation'
