from leapp.tags import Tag


class DeprecationPhaseTag(Tag):
    name = 'deprecation_phase_tag'
