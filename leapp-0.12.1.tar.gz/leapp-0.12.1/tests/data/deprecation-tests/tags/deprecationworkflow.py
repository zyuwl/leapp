from leapp.tags import Tag


class DeprecationWorkflowTag(Tag):
    name = 'deprecation_workflow'
