from leapp.tags import Tag


class ActorFileApiTag(Tag):
    name = 'actor_file_api'
