from leapp.topics import Topic


class ApiTestTopic(Topic):
    name = 'api_test'
