from leapp.topics import Topic


class ConfigTopic(Topic):
    name = 'config_topic'
