from leapp.tags import Tag


class FourthPhaseTag(Tag):
    name = 'fourth_phase'
