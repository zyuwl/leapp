from leapp.tags import Tag


class FifthPhaseTag(Tag):
    name = 'fifth_phase'
