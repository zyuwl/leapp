from leapp.tags import Tag


class ThirdPhaseTag(Tag):
    name = 'third_phase'
