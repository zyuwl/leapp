from leapp.tags import Tag


class UnitTestWorkflowTag(Tag):
    name = 'unit_test_workflow'
