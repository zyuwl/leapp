import json
import os
import time


DEFAULT_JSON_STATE_PATH = "/var/tmp/state.json"

def status_log_exists(path=DEFAULT_JSON_STATE_PATH):
    return os.path.exists(path)

def load_log_status(path=DEFAULT_JSON_STATE_PATH):
    if status_log_exists(path):
        with open(path, "r") as f:
            state = json.load(f)
        return state
    else:
        return None

def update_progress_infomation(progress=None, progress_info=None, err_no=None, err_msg=None, path=DEFAULT_JSON_STATE_PATH):
    if not os.path.exists(path):
        state_directory = path.rpartition('state.json')[0]
        if not os.path.exists(state_directory):
            os.makedirs(state_directory)

    state = load_log_status(path) or {"ErrorCode": 0 }

    if progress is not None:
        state["Progress"] = int(progress)
    if progress_info is not None:
        state["ProgressInfo"] = progress_info
    if err_no is not None:
        state["ErrorCode"] = err_no
    if err_msg is not None:
        state["ErrorMsg"] = err_msg

    state["Timestamp"] = int(time.time())

    with open(path, "w") as f:
        json.dump(state, f)
