import leapp.utils.workarounds.mp


def apply_workarounds():
    leapp.utils.workarounds.mp.apply_workaround()
