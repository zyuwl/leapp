from leapp.cli import main
import leapp.utils.i18n  # noqa: F401; pylint: disable=unused-import

main()
