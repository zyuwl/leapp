from leapp.utils.workarounds import apply_workarounds

VERSION = "0.12.0"
FULL_VERSION = VERSION

apply_workarounds()
