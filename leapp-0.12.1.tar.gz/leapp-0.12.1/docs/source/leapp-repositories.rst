Leapp repositories
==================

Here you can find all the information related to
`leapp repositories <terminology.html#repository>`_, including the documentation
for existing leapp repositories managed by the OS and Application
Modernization Group (`OAMG <https://github.com/oamg>`_)


.. toctree::
    :caption: Contents:

    repository-dir-layout
    el7toel8/leapp-repository-el7toel8
