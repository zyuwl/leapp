Leapp repository for RHEL 7 to RHEL 8 upgrade
=============================================
This is the official upstream documentation for the leapp repository for in-place upgrade (IPU) from RHEL 7 to RHEL 8. The homepage of the project is `here <https://github.com/oamg/leapp-repository>`_.

.. toctree::
    :caption: Contents:

    actor-rhel7-to-rhel8
    inhibit-rhel7-to-rhel8
    envars
