# Inplace Upgrade Workflow

[![In Place Upgrade Workflow](_static/images/inplace-upgrade-workflow.svg)](_static/images/inplace-upgrade-workflow.svg)
