See the [Contribution guidelines](https://leapp.readthedocs.io/en/latest/contributing.html)
