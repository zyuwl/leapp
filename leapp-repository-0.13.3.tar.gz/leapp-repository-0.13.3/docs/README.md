# Leapp repository documentation

The Leapp repository documentation has been moved to [Read the Docs](https://leapp.readthedocs.io/).
