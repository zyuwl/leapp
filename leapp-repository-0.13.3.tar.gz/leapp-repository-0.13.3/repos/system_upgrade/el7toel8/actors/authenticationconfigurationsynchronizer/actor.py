from leapp.actors import Actor
from leapp.tags import IPUWorkflowTag, ConfigurationSynchronizationPhaseTag
from leapp.models import ConfigurationSynchronization

import subprocess
import json


class AuthenticationConfigurationSynchronizer(Actor):
    """
    Keep authentication configuration the same after migration. This is synchronization phase.
    """

    name = 'authentication_configuration_synchronizer'
    consumes = (ConfigurationSynchronization, )
    produces = ()
    tags = (IPUWorkflowTag, ConfigurationSynchronizationPhaseTag, )

    def process(self):
        for configuration in self.consume(ConfigurationSynchronization):
            if configuration.sshd_auth_configuration is None:
                continue

            sshd_auth_configuration = json.loads(configuration.sshd_auth_configuration)
            PermitRootLogin = sshd_auth_configuration["PermitRootLogin"]
            PasswordAuthentication = sshd_auth_configuration["PasswordAuthentication"]

            if PermitRootLogin  == "DefaultValue":
                PermitRootLogin = "PermitRootLogin yes"
            if PasswordAuthentication == "DefaultValue":
                PasswordAuthentication = "# PasswordAuthentication yes"

            subprocess.run("sed -i '/PasswordAuthentication/d' /etc/ssh/sshd_config", shell=True)
            subprocess.run("sed -i '/PermitRootLogin/d' /etc/ssh/sshd_config", shell=True)
            subprocess.run("sed -i '$a\%s' /etc/ssh/sshd_config" % PasswordAuthentication, shell=True)
            subprocess.run("sed -i '$a\%s' /etc/ssh/sshd_config" % PermitRootLogin, shell=True)
            subprocess.run("systemctl restart sshd", shell=True)
