from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.libraries.stdlib import run
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent
import subprocess


class CheckPackagesForUpgrade(Actor):
    """
    Check version of some packages that may have impact on upgrade process
    """

    name = 'checkpkgforupgrade'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    dialogs = (
        Dialog(
            scope='update_grub2-tools',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Update grub2-tools? '
                          'If no, the upgrade process will be interrupted.',
                    description='grub2 version is too low for system upgrade.',
                    reason='grub2 version must be upgrade to version >= 2.02-0.64, '
                           'otherwise system upgrade will get failed after reboot.'
                ),
            )
        ),
        Dialog(
            scope='update_python-devel',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Update python-devel ? '
                          'If not, the upgrade process will be interrupted.',
                    description='python-devel version is too low for system upgrade.',
                    reason='python-devel version must be upgrade to version >= 2.7.5-77, '
                           'otherwise system upgrade will get failed after reboot.'
                ),
            )
        ),
    )

    def get_releasever_of_rpm(self, pkg_name):
        rel_ver = run(['rpm', '-q', pkg_name, '--qf', '%{RELEASE}'], split=False)['stdout']
        return rel_ver

    def compare_version(self, ver1, ver2):
        """
        ver1 < ver2, return -1
        ver1 = ver2, return 0
        ver1 > ver2, return 1
        """
        list1 = str(ver1).split(".")
        list2 = str(ver2).split(".")
        if len(list1) > len(list2):
            length = len(list2)
        else:
            length = len(list1)

        for i in range(0, length):
            if list1[i] > list2[i]:
                return 1
            elif list1[i] < list2[i]:
                return -1
        if len(list1) > len(list2):
            return 1
        elif len(list1) < len(list2):
            return -1
        else:
            return 0


    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'grub2'):
            grub2_version = self.get_releasever_of_rpm('grub2')

            if self.compare_version(grub2_version, '0.64') < 0:
                answer = self.get_answers(self.dialogs[0])
                if answer.get('confirm') == True:
                    subprocess.call(['yum', 'update', '-y', 'grub2'])
                else:
                    commands = [['yum', '-y', 'update', 'grub2']]
                    create_report([
                        reporting.Title('grub2 version is too low for system upgrade'),
                        reporting.Summary(
                            'grub2 version must be upgrade to version >= 2.02-0.64, '
                            'otherwise system upgrade will get failed after reboot.'
                        ),
                        reporting.Severity(reporting.Severity.HIGH),
                        reporting.Flags([reporting.Flags.INHIBITOR]),
                        reporting.Remediation(commands=commands),
                        reporting.RelatedResource('package', 'grub2'),
                    ])

        if has_package(InstalledRedHatSignedRPM, 'python-devel'):
            python_devel_version = self.get_releasever_of_rpm('python-devel')
            
            if self.compare_version(python_devel_version, '77.el7_6') <= 0:
                answer = self.get_answers(self.dialogs[1])
                if answer.get('confirm') == True:
                    subprocess.call(['yum', 'update', '-y', 'python-devel'])
                else:
                    commands = [['yum', '-y', 'update', 'python-devel']]
                    create_report([
                        reporting.Title('python-devel version is too low for system upgrade'),
                        reporting.Summary(
                            'python-devel version must be upgrade to version > 2.7.5-77, '
                            'otherwise system upgrade will get failed after reboot.'
                        ),
                        reporting.Severity(reporting.Severity.HIGH),
                        reporting.Flags([reporting.Flags.INHIBITOR]),
                        reporting.Remediation(commands=commands),
                        reporting.RelatedResource('package', 'python-devel'),
                    ])
