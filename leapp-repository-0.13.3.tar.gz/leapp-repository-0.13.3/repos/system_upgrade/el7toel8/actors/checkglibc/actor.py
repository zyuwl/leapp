from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckGlibc(Actor):
    """
    Show important changes of glibc
    """

    name = 'checkglibc'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'glibc'):
            create_report([
                reporting.Title('Some important changes about glibc'),
                reporting.Summary(
			'The GLIBC version of Anolis8 is 2.28. '
			'This version no longer supports nss related modules, '
			'no longer providing libnss_nis.so, libnss_nisplus.so. \n'
			'/etc/nsswitch.conf deletes all configurations related to nis. '
			'The fast cache mechanism provided by the sssd can enhance the parsing performance of user and groups, '
			'/etc/nsswitch.conf defaults to set the preferences for passwd and group for sss.\n'
			'All code that relies and uses the nis module requires rectification, you can use tirpc instead.'
                ),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.RelatedResource('package', 'glibc')
            ])
