import subprocess

from leapp.actors import Actor
from leapp.models import StorageInfo
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.libraries.stdlib import api
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class CheckOSSfs(Actor):
    """
    Check if OSSFS filesystem is in use. If yes, inhibit the upgrade process.

    Actor looks for OSSFS in the following sources: /ets/fstab, mount and systemd-mount.
    If there is OSSFS in any of the mentioned sources, actors inhibits the upgrade.
    """
    name = "check_ossfs"
    consumes = (StorageInfo,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag,)
    
    dialogs = (
        Dialog(
            scope='cancle_ossfs_mount_in_fstab',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Cancle ossfs mount in fstab? '
                          'If no, the upgrade process will be interrupted.',
                    description='Deprecated OSSFS mount present in /etc/fstab.',
                    default=True,
                    reason='OSSFS is currently not supported by the inplace upgrade.'
                ),
            )
        ),
    )

    def process(self):
        details = "OSSFS is currently not supported by the inplace upgrade.\n" \
                  "We have found OSSFS usage at the following locations:\n"

        for storage in self.consume(StorageInfo):
            # Check fstab
            fstab_ossfs_mounts = []
            for fstab in storage.fstab:
                if fstab.fs_spec.startswith('ossfs') and fstab.fs_vfstype == 'fuse' :
                    fstab_ossfs_mounts.append(" - {} {}\n".format(fstab.fs_spec, fstab.fs_file))

            # Check mount
            ossfs_mounts = []
            for mount in storage.mount:
                if mount.tp.find('ossfs') != -1 : 
                    ossfs_mounts.append(" - {} {}\n".format(mount.name, mount.mount))

            # Check systemd-mount
            systemd_ossfs_mounts = []
            for systemdmount in storage.systemdmount:
                if systemdmount.fs_type.find('ossfs') != -1 : 
                    # mountpoint is not available in the model
                    systemd_ossfs_mounts.append(" - {}\n".format(systemdmount.node))
            
        if ossfs_mounts:
            details += "- OSSFS shares currently mounted:\n"
            details += ''.join(ossfs_mounts)

        if systemd_ossfs_mounts:
            details += "- OSSFS mounts configured with systemd-mount:\n"
            details += ''.join(systemd_ossfs_mounts)

        if fstab_ossfs_mounts:
            details += "- OSSFS shares found in /etc/fstab:\n"
            details += ''.join(fstab_ossfs_mounts)
            api.current_logger().info(details)

            command = "sed -i '/ossfs/ s/^/#/' /etc/fstab"
            answer = self.get_answers(self.dialogs[0])
            if answer.get('confirm') == True:
                try:
                    subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
                except subprocess.CalledProcessError as e:
                    api.current_logger().error('comment out OSSFS mount failed: {}'.format(e))
                else:
                    api.current_logger().info('comment out OSSFS mount succeeded: {}'.format(command))
                    return
                
            fstab_related_resource = [reporting.RelatedResource('file', '/etc/fstab')] if fstab_ossfs_mounts else []

            create_report([
                reporting.Title("Use of OSSFS detected. Upgrade can't proceed"),
                reporting.Summary(details),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Tags([
                        reporting.Tags.FILESYSTEM,
                        reporting.Tags.NETWORK
                ]),
                reporting.Remediation(hint='Disable OSSFS temporarily for the upgrade if possible.'),
                reporting.Flags([reporting.Flags.INHIBITOR]),
                ] + fstab_related_resource
            )
