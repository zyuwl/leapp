from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckOpenssl(Actor):
    """
    Check if openssl is installed. If yes, write information about important changes.
    """

    name = 'checkopenssl'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        removed_ciphers = '''DH-DSS-AES256-GCM-SHA384
DH-RSA-AES256-GCM-SHA384
DH-RSA-AES256-SHA256
DH-DSS-AES256-SHA256
DH-RSA-AES256-SHA
DH-DSS-AES256-SHA
DH-RSA-CAMELLIA256-SHA
DH-DSS-CAMELLIA256-SHA
ECDH-RSA-AES256-GCM-SHA384
ECDH-ECDSA-AES256-GCM-SHA384
ECDH-RSA-AES256-SHA384
ECDH-ECDSA-AES256-SHA384
ECDH-RSA-AES256-SHA
ECDH-ECDSA-AES256-SHA
DH-DSS-AES128-GCM-SHA256
DH-RSA-AES128-GCM-SHA256
DH-RSA-AES128-SHA256
DH-DSS-AES128-SHA256
DH-RSA-AES128-SHA
DH-DSS-AES128-SHA
DH-RSA-SEED-SHA
DH-DSS-SEED-SHA
DH-RSA-CAMELLIA128-SHA
DH-DSS-CAMELLIA128-SHA
ECDH-RSA-AES128-GCM-SHA256
ECDH-ECDSA-AES128-GCM-SHA256
ECDH-RSA-AES128-SHA256
ECDH-ECDSA-AES128-SHA256
ECDH-RSA-AES128-SHA
ECDH-ECDSA-AES128-SHA
EDH-RSA-DES-CBC3-SHA
EDH-DSS-DES-CBC3-SHA
DH-RSA-DES-CBC3-SHA
DH-DSS-DES-CBC3-SHA
ECDH-RSA-DES-CBC3-SHA
ECDH-ECDSA-DES-CBC3-SHA
KRB5-IDEA-CBC-SHA
KRB5-DES-CBC3-SHA
KRB5-IDEA-CBC-MD5
KRB5-DES-CBC3-MD5
ECDH-RSA-RC4-SHA
ECDH-ECDSA-RC4-SHA
RC4-MD5
KRB5-RC4-SHA
KRB5-RC4-MD5'''
        if has_package(InstalledRedHatSignedRPM, 'openssl') or has_package(InstalledRedHatSignedRPM, 'openssl-libs'):
            create_report([
                reporting.Title('openssl ciphers have import changes between 1.0.2 and 1.1.1'),
                reporting.Summary(
                   'Anolis8 will introduce openssl 1.1.1, openssl-1.1.1 remove some ciphers '
                   'which are default enabled on openssl-1.0.2, these ciphers are:\n{}'
                   .format(removed_ciphers)
                ),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Remediation(hint='Please make sure your application do not use these ciphers and modify to use other ciphers.'),
                reporting.RelatedResource('package', 'openssl')
            ])
