from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.reporting import create_report
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
import subprocess

class Checkbaota(Actor):
    """
    Check if baota is installed. If yes, stop upgrade
    """

    name = 'checkbaota'
    consumes = (InstalledRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRPM,"openssl"):
            try:
                ret = subprocess.check_output(["bt","default"])
                if "BT-Panel default info" in ret:
                    create_report([
                        reporting.Title('Baota is installed, openssl version cannot be processed during upgrade.'),
                        reporting.Summary(
                            'Baota has openssl-libs cannot be updated to Anolis OS 8.\n'
                            'You should first backup your application files and data when baota requires openssl-libs. Secondly, install new version for baota after migration and recover the data.'),
                        reporting.Severity(reporting.Severity.HIGH),
                        reporting.Remediation(hint='Please uninstall baota, and then preupgrade again.'),
                    ])
            except:
                pass

