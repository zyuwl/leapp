from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckMandb(Actor):
    """
    Check if mandb is installed. If yes, write information about important changes.
    """

    name = 'checkmandb'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'man-db'):
            create_report([
                reporting.Title('man-db.cron is not enabled by default'),
                reporting.Summary(
                   'Anolis8 move /etc/cron.d/man-db.cron from man-db to man-db-cron, '
                   'man-db.cron is used to periodic update of man-db cache, '
                   'if you need this feature, please instal man-db-cron.'
                ),
                reporting.Severity(reporting.Severity.LOW),
                reporting.RelatedResource('package', 'man-db')
            ])
