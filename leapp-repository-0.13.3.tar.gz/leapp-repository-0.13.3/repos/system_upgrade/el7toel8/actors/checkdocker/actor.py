from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckDocker(Actor):
    """
    Check if docker is installed. If yes, write information about important changes.
    """

    name = 'checkdocker'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'docker') or has_package(InstalledRedHatSignedRPM, 'docker-client') or has_package(InstalledRedHatSignedRPM, 'docker-common'):
            create_report([
                reporting.Title('Some important changes with docker'),
                reporting.Summary(
                   'In Anolis 8, docker is provided by podman-docker defaultly, and docker is just swapper of podman.\n'
                   'Anolis 8 provides podman/runc/crun/buildah/skopo same as RedHat 8, refer to https://access.redhat.com/documentation/en-us/red_hat_enterprise_linux/8/html-single/building_running_and_managing_containers.\n'
                   'Anolis 8 also provides solutions to use docker-ce, refer to https://openanolis.cn/sig/third_software_compatibility/doc/400880695004037434.'
                ),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Remediation(hint='Please note the change of docker on anolis8.'),
                reporting.RelatedResource('package', 'docker')
            ])

