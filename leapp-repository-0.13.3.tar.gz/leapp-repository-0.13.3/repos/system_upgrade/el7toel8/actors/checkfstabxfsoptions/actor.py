from leapp.actors import Actor
from leapp.libraries.actor import checkfstabxfsoptions
from leapp.models import StorageInfo
from leapp.reporting import Report
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class CheckFstabXFSOptions(Actor):
    """
    Check the FSTAB file for the deprecated / removed XFS mount options.

    Some mount options for XFS have been deprecated on RHEL 7 and already
    removed on Anolis 8. If any such an option is present in the FSTAB,
    it's impossible to boot the Anolis 8 system without the manual update of the
    file.

    Check whether any of these options are present in the FSTAB file
    and inhibit the upgrade in such a case.
    """

    name = 'checkfstabxfsoptions'
    consumes = (StorageInfo,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)
    
    dialogs = (
        Dialog(
            scope='change_fstab_xfs_options',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Change fstab xfs options? '
                          'If no, the upgrade process will be interrupted.',
                    description='Deprecated XFS mount options present in fstab.',
                    default=True,
                    reason='Some XFS mount options are not supported.'
                ),
            )
        ),
    )
    
    def is_confirm(self):
        answer = self.get_answers(self.dialogs[0])
        return answer.get('confirm')

    def process(self):
        checkfstabxfsoptions.process(self.is_confirm)
