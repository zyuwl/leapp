from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckAudit(Actor):
    """
    Check if audit is installed. If yes, write information about audit changes.
    """

    name = 'checkaudit'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'audit'):
            create_report([
                reporting.Title('audispd is moved from audit to audispd-plugins'),
                reporting.Summary(
                   'In Anolis8, audispd related files is moved to audispd-plugins package, '
                   'and audispd-plugins is not installed by default, if you want to use audispd, '
                   'please install audispd-plugins.'
                ),
                reporting.Severity(reporting.Severity.LOW),
                reporting.RelatedResource('package', 'audit')
            ])
