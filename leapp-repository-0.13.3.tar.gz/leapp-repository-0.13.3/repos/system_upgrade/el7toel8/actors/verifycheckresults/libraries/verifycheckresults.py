from leapp.exceptions import RequestStopAfterPhase
from leapp.libraries.stdlib import api
from leapp.reporting import Report
from leapp.libraries.common import smc_interface

inhibitor_list = []
inhibitor_flag = 0

def check():
    for msg in api.consume(Report):
        if 'inhibitor' in msg.report.get('flags', []):
            global inhibitor_flag
            inhibitor_flag = 1
            inhibitor_list.append(str(msg.report.get('title', [])))

    if inhibitor_flag == 1:
        # The err_msg length is currently limited to 512, which can be adjusted
        smc_interface.update_progress_infomation(err_no=199, err_msg="|".join(inhibitor_list)[:512])
        raise RequestStopAfterPhase()
