import os
import subprocess

from leapp import reporting
from leapp.actors import Actor
from leapp.exceptions import StopActorExecutionError
from leapp.models import Report, RootDirectory
from leapp.tags import IPUWorkflowTag, ChecksPhaseTag
from leapp.libraries.stdlib import api
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class CheckRootSymlinks(Actor):
    """
    Check if the symlinks /bin and /lib are relative, not absolute.

    After reboot, dracut fails if the links are absolute.
    """

    name = 'check_root_symlinks'
    consumes = (RootDirectory,)
    produces = (Report,)
    tags = (IPUWorkflowTag, ChecksPhaseTag)
    
    dialogs = (
        Dialog(
            scope='change_root_symlinks',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Change symlinks in root directory? '
                          'If no, the upgrade process will be interrupted.',
                    description='Upgrade requires links in root directory to be relative.',
                    default=True,
                    reason='After rebooting, parts of the upgrade process can fail if symbolic links in / point to absolute paths. '
                ),
            )
        ),
    )

    def process(self):
        rootdir = next(self.consume(RootDirectory), None)
        if not rootdir:
            raise StopActorExecutionError('Cannot check root symlinks',
                                          details={'Problem': 'Did not receive a message with '
                                                              'root subdirectories'})
        absolute_links = [item for item in rootdir.items if item.target and os.path.isabs(item.target)]

        if absolute_links:
            commands = [' '.join(['ln', '-snf',
                                  os.path.relpath(item.target, '/'),
                                  os.path.join('/', item.name)]) for item in absolute_links]
            remediation = [['sh', '-c', ' && '.join(commands)]]
            answer = self.get_answers(self.dialogs[0])
            if answer.get('confirm') == True:
                try:
                    subprocess.check_output(commands, shell=True, stderr=subprocess.STDOUT)
                except subprocess.CalledProcessError as e:
                    api.current_logger().error('change symlinks to relative paths failed: {}'.format(e))
                else:
                    api.current_logger().info('change symlinks to relative paths succeeded: {}'.format(commands))
                    return
 
            reporting.create_report([
                reporting.Title('Upgrade requires links in root directory to be relative'),
                reporting.Summary(
                    'After rebooting, parts of the upgrade process can fail if symbolic links in / '
                    'point to absolute paths.\n'
                    'Please change these links to relative ones.'
                ),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Flags([reporting.Flags.INHIBITOR]),
                reporting.Remediation(commands=remediation)
            ])
