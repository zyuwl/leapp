from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckSysvinittools(Actor):
    """
    Check if sysvinit-tools is installed. If yes, write information about important changes.
    """

    name = 'checksysvinittools'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'sysvinit-tools'):
            create_report([
                reporting.Title('sysvinit-tools is replaced by util-linux and procps-ng'),
                reporting.Summary(
                   'In Anolis 8, sysvinit-tools is removed, sysvinit-tools contains the following commands: last, lastb, mesg, wall, pidof and killall5. '
                   'In Anolis 8 system, last, lastb, mesg and wall are provided by util-linux, pidof is provided by procps-ng.\n'
                   'Killall5 is a systemV command, the Centos 7 / Centos 8 are now based on systemd. '
                   'In addition, pidof provided by sysvinit-tools is actually a soft link to killall5. In Anolis 8, pidof is provided by procps-ng instead. '
                   'So, sysvinit-tools in Anolis 8 is replaced by util-linux and procps-ng. '
                ),
                reporting.Severity(reporting.Severity.LOW),
                reporting.RelatedResource('package', 'sysvinit-tools')
            ])
