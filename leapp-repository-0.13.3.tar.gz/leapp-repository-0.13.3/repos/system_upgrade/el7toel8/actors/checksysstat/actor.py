from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckSysstat(Actor):
    """
    Check if sysstat is installed. If yes, write information about sysstat changes.
    """

    name = 'checksysstat'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'sysstat'):
            create_report([
                reporting.Title('sysstat cron task is replaced by sysstat-collect and sysstat-summary'),
                reporting.Summary(
                   'In Anolis8, sysstat-collect will collect system activity accounting, '
                   'sysstat-summary will generate a daily summary of process accounting.'
                   '/etc/cron.d/sysstat is removed from sysstat for cron task is replaced by '
                   'sysstat-collect.timer and sysstat-summary.timer.'
                ),
                reporting.Severity(reporting.Severity.LOW),
                reporting.RelatedResource('package', 'sysstat')
            ])
