from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag


class CheckSystemd(Actor):
    """
    Show important changes of systemd config
    """

    name = 'checksystemd'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'systemd'):
            create_report([
                reporting.Title('systemd related configs have importand changes in new version'),
                reporting.Summary(
                   '/etc/systemd/journal.conf import two options: SystemMaxFiles and RuntimeMaxFiles. '
                   'These two options are used to limit the count of journal files, default is 100. '
                   'So in Anolis8, the default journal files will be 100, and the journal files older'
                   'than 100 will be removed, thus system logs will be lost when os has large number of logs.\n'
                   '/etc/systemd/journal.conf move option ForwordToSyslog from yes to no by default, '
                   'this means that logs recevied by journal are no longer forwarded to syslog by default, '
                   'Anolis8 use rsyslog by default and rsyslog reads directly journal data.\n'
                   '/etc/systemd/system.conf rename CrashChVT to CrashChangeVT, the old options are still compatible, '
                   'but the valut meaning of CrashChangeVT has changed. '
                   'Centos7 accepts int type parameters, '
                   'where a positive number represents the virtual terminal corresponding to this number when systemd crashes, such as /dev/tty1, '
                   'and a zero or negative number indicates that systemd does not switch virtual terminals when systemd crashes. '
                   'In anolis8, it accepts positive or bool type parameters, but it is still compatible with the old parameter types. '
                   'A positive number means that systemd will switch to the virtual terminal corresponding to this number when a crash occurs. '
                   'A negative number /0/no/n/false/f/off means that systemd will not switch the virtual terminal when a crash occurs. '
                   'The yes/y/true/t/on parameter represents the virtual terminal that switches to the kernel log printing when systemd crashes. '
                   'The value of this parameter changes from 1 to no before and after the switch, indicating that the terminal will not be switched when systemd crashes.\n'
                   '/etc/systemd/system.conf configuration option DefaultTasksMax changes: '
                   'There is no limit by default in centos7. '
                   'In anolis8.2, the number of threads that each service can have is min (kernel.pid_max, kernel.threads-max, pids.max of root-cgroup) * 80% by default.\n'
                ),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.RelatedResource('package', 'systemd')
            ])
