import subprocess
import json

from leapp.actors import Actor
from leapp.tags import ConfigurationCollectionPhaseTag, IPUWorkflowTag
from leapp.models import ConfigurationSynchronization


class ServiceConfigurationCollector(Actor):
    """
    No documentation has been provided for the service_configuration_collector actor.
    """

    name = 'service_configuration_collector'
    consumes = ()
    produces = (ConfigurationSynchronization, )
    tags = (ConfigurationCollectionPhaseTag, IPUWorkflowTag, )

    def process(self):
        self.log.info("Starting to backup service configurations.")
        services_config_raw = subprocess.check_output("systemctl list-unit-files | egrep 'enabled|disabled'", shell=True).decode("utf-8").strip()
        services_config = {
            line.strip().split()[0]: line.strip().split()[1][:-1]
            for line in services_config_raw.split('\n')
        }
        self.produce(ConfigurationSynchronization(services_configuration=json.dumps(services_config)))

