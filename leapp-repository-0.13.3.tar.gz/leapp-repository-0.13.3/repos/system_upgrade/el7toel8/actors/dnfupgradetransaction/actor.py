import shutil

from leapp.actors import Actor
from leapp.libraries.common import dnfplugin
from leapp.libraries.stdlib import run
from leapp.models import (
    DNFPluginTask,
    FilteredRpmTransactionTasks,
    RHSMInfo,
    StorageInfo,
    TargetUserSpaceInfo,
    TransactionCompleted,
    UsedTargetRepositories,
)
from leapp.tags import IPUWorkflowTag, RPMUpgradePhaseTag
import subprocess
import re


class DnfUpgradeTransaction(Actor):
    """
    Setup and call DNF upgrade command

    Based on previously calculated RPM transaction data, this actor will setup and call
    rhel-upgrade DNF plugin with necessary parameters
    """

    name = 'dnf_upgrade_transaction'
    consumes = (
        DNFPluginTask,
        FilteredRpmTransactionTasks,
        RHSMInfo,
        StorageInfo,
        TargetUserSpaceInfo,
        UsedTargetRepositories,
    )
    produces = (TransactionCompleted,)
    tags = (RPMUpgradePhaseTag, IPUWorkflowTag)

    grub2_migrear_prefix = 'title=MigReaR-'

    def process(self):
        src_rhsm_info = next(self.consume(RHSMInfo), None)
        if src_rhsm_info:
            for prod_cert in src_rhsm_info.existing_product_certificates:
                run(['rm', '-f', prod_cert])

        used_repos = self.consume(UsedTargetRepositories)
        storage_info = next(self.consume(StorageInfo), None)
        plugin_info = list(self.consume(DNFPluginTask))
        tasks = next(self.consume(FilteredRpmTransactionTasks), FilteredRpmTransactionTasks())
        target_userspace_info = next(self.consume(TargetUserSpaceInfo), None)

        output = subprocess.check_output("grubby --info=ALL", shell=True).strip()
        grub_entries = output.split('index=')

        migrear_entries = []
        for entry in grub_entries:
            if self.grub2_migrear_prefix in entry:
                kernel = re.findall(r"kernel=(/.*)\n", entry)
                nargs = re.findall(r"args=(.*)\n", entry)
                initrd = re.findall(r"initrd=(.*)\n", entry)
                title = re.findall(r"title=(.*)\n", entry)
                if len(kernel) == 1 and len(initrd) == 1 and len(title) == 1:
                    migrear_entries += [{
                        "kernel": kernel[0],
                        "args": nargs[0] if len(nargs) == 1 else "",
                        "initrd": initrd[0],
                        "title": title[0],
                    }]

        dnfplugin.perform_transaction_install(
            tasks=tasks, used_repos=used_repos, storage_info=storage_info, target_userspace_info=target_userspace_info,
            plugin_info=plugin_info
        )

        for entry in migrear_entries:
            try:
                subprocess.check_call("grubby --copy-default --add-kernel %s --initrd %s --args=%s --title=%s" % (entry['kernel'], entry['initrd'], entry['args'], entry['title']), shell=True)
            except Exception as e:
                self.log.info(" ".join(["Failed restore migrear entry", str(entry), "Exception:", str(e)]), exc_info=True)

        self.produce(TransactionCompleted())
        userspace = next(self.consume(TargetUserSpaceInfo), None)
        if userspace:
            try:
                shutil.rmtree(userspace.path)
            except EnvironmentError:
                self.log.info("Failed to remove temporary userspace - error ignored", exc_info=True)
