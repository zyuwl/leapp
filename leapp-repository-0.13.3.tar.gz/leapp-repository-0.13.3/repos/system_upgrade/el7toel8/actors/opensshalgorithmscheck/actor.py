from leapp.actors import Actor
from leapp.libraries.actor import opensshalgorithmscheck
from leapp.models import Report, OpenSshConfig
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class OpenSshAlgorithmsCheck(Actor):
    """
    OpenSSH configuration does not contain any unsupported cryptographic algorithms.

    Check the values of Ciphers and MACs in OpenSSH server config file and warn
    about removed algorithms which might cause the server to fail to start.
    """
    name = 'open_ssh_algorithms'
    consumes = (OpenSshConfig,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)
    
    dialogs = (
        Dialog(
            scope='remove_openssh_cipher',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    default=True,
                    label='Remove the disabled ciphers from sshd_config? '
                          'If no, the upgrade process will be interrupted.',
                    description='OpenSSH configured to use removed ciphers.',
                    reason='These ciphers were removed from OpenSSH.'
                ),
            )
        ),
        Dialog(
            scope='remove_openssh_mac',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    default=True,
                    label='Remove the disabled MACs from sshd_config? '
                          'If no, the upgrade process will be interrupted.',
                    description='OpenSSH configured to use removed mac.',
                    reason='This MAC was removed from OpenSSH.'
                ),
            )
        ),
    )

    def is_confirm_ciphers(self):
        answer = self.get_answers(self.dialogs[0])
        return answer.get('confirm', False)
    
    def is_confirm_mac(self):
        answer = self.get_answers(self.dialogs[1])
        return answer.get('confirm', False)

    def process(self):
        opensshalgorithmscheck.process(self.consume(OpenSshConfig), self.is_confirm_ciphers, self.is_confirm_mac)
