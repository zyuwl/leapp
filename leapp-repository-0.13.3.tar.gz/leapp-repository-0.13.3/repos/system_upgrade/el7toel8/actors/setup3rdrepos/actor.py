import platform

from leapp.actors import Actor
from leapp.libraries.common import repofileutils
from leapp.libraries.common.rpms import has_package
from leapp.models import (CustomTargetRepository, CustomTargetRepositoryFile, InstalledUnsignedRPM)
from leapp.tags import FactsPhaseTag, IPUWorkflowTag

CANDIDATE_REPOS = ['nodesource', 'zabbix', 'zabbix-frontend', 'docker-ce-stable']

class Setup3rdRepos(Actor):
    """
    Setup 3rd repositories available if there is pkg installed from 3rd repo.
    """

    name = 'setup3rdrepos'
    consumes = (CustomTargetRepositoryFile, InstalledUnsignedRPM)
    produces = (CustomTargetRepository,)
    tags = (IPUWorkflowTag, FactsPhaseTag)

    def process(self):
        repos_3rd = set()
        for rpm_pkgs in self.consume(InstalledUnsignedRPM):
            for pkg in rpm_pkgs.items:
                if pkg.repository in CANDIDATE_REPOS:
                    repos_3rd.add(pkg.repository)

        custom_repos_map = {}
        for ctrf in self.consume(CustomTargetRepositoryFile):
            repofile = repofileutils.parse_repofile(ctrf.file)
            for repo in repofile.data:
                custom_repos_map[repo.repoid] = repo

        for repo in repos_3rd:
            repoid = repo + '-migrate'
            if repoid in custom_repos_map.keys():
                self.produce(CustomTargetRepository(
                    repoid=custom_repos_map[repoid].repoid,
                    name=custom_repos_map[repoid].name,
                    baseurl=custom_repos_map[repoid].baseurl,
                    enabled=True,
                ))
