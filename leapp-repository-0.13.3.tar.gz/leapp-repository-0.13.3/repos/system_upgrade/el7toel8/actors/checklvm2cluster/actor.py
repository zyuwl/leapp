import subprocess

from leapp.actors import Actor
from leapp.libraries.common.rpms import has_package
from leapp.models import InstalledRedHatSignedRPM
from leapp.reporting import Report, create_report
from leapp import reporting
from leapp.reporting import create_report
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.libraries.stdlib import api
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class Checklvm2cluster(Actor):
    """
    Check if lvm2-cluster is installed. If yes, stop upgrade
    """

    name = 'check-lvm2-cluster'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    dialogs = (
        Dialog(
            scope='remove_lvm2-cluster',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Remove lvm2-cluster? '
                          'If no, the upgrade process will be interrupted.',
                    description='lvm2-cluster must be removed prior the upgrade.',
                    default=True,
                    reason='The preun scriptlet of the lvm2-cluster package will cause failure.'
                ),
            )
        ),
    )

    def process(self):
        if has_package(InstalledRedHatSignedRPM, 'lvm2-cluster'):
            command = "yum remove -y lvm2-cluster "
            answer = self.get_answers(self.dialogs[0])
            if answer.get('confirm') == True:
                try:
                    subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
                except subprocess.CalledProcessError as e:
                    api.current_logger().error('remove lvm2-cluster failed: {}'.format(e))
                else:
                    api.current_logger().info('remove lvm2-cluster succeeded: {}'.format(command))
                    return
                
            create_report([
                reporting.Title('lvm2-cluster is installed, lvm2-cluster cannot be processed during upgrade'),
                reporting.Summary('lvm2-cluster affects the upgrade and needs to be uninstalled first'),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Remediation(hint='Use "yum remove -y lvm2-cluster" before "leapp preupgrade --no-rhsm" '),
                reporting.Flags([reporting.Flags.INHIBITOR])
            ])
