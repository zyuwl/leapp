from leapp.actors import Actor
from leapp.models import InstalledRedHatSignedRPM
from leapp.tags import IPUWorkflowTag, ChecksPhaseTag
from leapp.reporting import Report
from leapp.libraries.actor import checkinstalleddevelkernels
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent


class CheckInstalledDevelKernels(Actor):
    """
    Inhibit IPU (in-place upgrade) when multiple devel kernels are installed.

    Because of an issue in DNF, the transaction can't be validated if there's
    more than one package named kernel-devel. Therefore, in this case, we
    inhibit the upgrade with a clearer remediation.
    """

    name = 'check_installed_devel_kernels'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (IPUWorkflowTag, ChecksPhaseTag)

    dialogs = (
        Dialog(
            scope='keep_only_one_kernel-devel',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Keep Only one kernel-devel ? '
                          'If not, the upgrade process will be interrupted.',
                    description='Remove all but one kernel-devel packages before running Leapp',
                    default=False,
                    reason ='DNF cannot produce a valid upgrade transaction when'
                            ' multiple kernel-devel packages are installed.'
                ),
            )
        ),
    )

    def is_confirm(self):
        answer = self.get_answers(self.dialogs[0])
        return answer.get('confirm', False)

    def process(self):
        checkinstalleddevelkernels.process(self.is_confirm)
