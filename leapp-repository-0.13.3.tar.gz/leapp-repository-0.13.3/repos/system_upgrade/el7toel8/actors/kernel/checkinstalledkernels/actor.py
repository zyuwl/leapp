from leapp.actors import Actor
from leapp.models import InstalledRedHatSignedRPM
from leapp.tags import IPUWorkflowTag, ChecksPhaseTag
from leapp.reporting import Report
from leapp.libraries.actor import checkinstalledkernels
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class CheckInstalledKernels(Actor):
    """
    Inhibit IPU (in-place upgrade) when installed kernels conflict with a safe upgrade.

    a) Inhibit when multiple kernels are installed on a s390x machine

    When on s390x architecture, we are not able to upgrade correctly
    when any kernel is expected to be uninstalled during the rpm
    upgrade transaction now. We discovered recently that removal of
    old kernels is not handled correctly during the IPU. In case the
    maximum number of kernels are installed, the oldest one is
    automatically uninstalled during the rpm upgrade transaction.

    To prevent any related troubles during the IPU, inhibit the IPU
    on s390x unless just one kernel is installed, until the issue will
    be fixed correctly.

    b) Inhibit when machine is not booted into latest installed kernel

    It is strictly required that during the upgrade the machine is
    booted into the latest installed kernel. Upgrading with older
    kernels could cause unexpected issues.
    """

    name = 'check_installed_kernels'
    consumes = (InstalledRedHatSignedRPM,)
    produces = (Report,)
    tags = (IPUWorkflowTag, ChecksPhaseTag)

    dialogs = (
        Dialog(
            scope='remove_extra_kernel',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Remove extra kernel? '
                          'If no, the upgrade process will be interrupted.',
                    description='Newest installed kernel not in use.',
                    default=True,
                    reason='To ensure a stable upgrade, the machine needs to be '
                           'booted into the latest installed kernel.'
                ),
            )
        ),
    )

    def is_confirm(self):
        answer = self.get_answers(self.dialogs[0])
        return answer.get('confirm', False)

    def process(self):
        checkinstalledkernels.process(self.is_confirm)
