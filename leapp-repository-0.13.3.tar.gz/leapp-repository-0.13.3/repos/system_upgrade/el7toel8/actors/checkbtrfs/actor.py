import subprocess

from leapp.actors import Actor
from leapp.models import ActiveKernelModulesFacts
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp import reporting
from leapp.reporting import Report, create_report
from leapp.libraries.stdlib import api
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent


class CheckBtrfs(Actor):
    """
    Check if Btrfs filesystem is in use. If yes, inhibit the upgrade process.

    Btrfs filesystem was introduced as Technology Preview with initial releases of RHEL 6 and 7. It
    was deprecated on versions 6.6 and 7.4 and will not be present in next major version.
    """

    name = 'check_btrfs'
    consumes = (ActiveKernelModulesFacts,)
    produces = (Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    dialogs = (
        Dialog(
            scope='remove_btrfs_module',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Remove btrfs module? '
                          'If no, the upgrade process will be interrupted.',
                    description='Btrfs has been removed from Anolis 8.',
                    default=True,
                    reason='Btrfs filesystem was deprecated on versions 6.6 and 7.4 and will not be present in Anolis 8. '
                ),
            )
        ),
    )

    def process(self):
        for fact in self.consume(ActiveKernelModulesFacts):
            for active_module in fact.kernel_modules:
                if active_module.filename == 'btrfs':
                    command = "rmmod btrfs"
                    answer = self.get_answers(self.dialogs[0])
                    if answer.get('confirm') == True:
                        try:
                            subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
                        except subprocess.CalledProcessError as e:
                            api.current_logger().error('remove btrfs module failed: {}'.format(e))
                        else:
                            api.current_logger().info('remove btrfs module succeeded: {}'.format(command))
                            return
                    
                    create_report([
                        reporting.Title('Btrfs has been removed from Anolis 8'),
                        reporting.Summary(
                            'The Btrfs file system was introduced as Technology Preview with the '
                            'initial release of Red Hat Enterprise Linux 6 and Red Hat Enterprise Linux 7. As of '
                            'versions 6.6 and 7.4 this technology has been deprecated and removed in Anolis 8.'
                        ),
                        reporting.Severity(reporting.Severity.HIGH),
                        reporting.Flags([reporting.Flags.INHIBITOR]),
                        reporting.Tags([reporting.Tags.FILESYSTEM]),
                        reporting.RelatedResource('kernel-driver', 'btrfs')
                    ])
                    break
