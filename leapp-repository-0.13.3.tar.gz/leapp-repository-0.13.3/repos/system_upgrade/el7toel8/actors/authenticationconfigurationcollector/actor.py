from leapp.actors import Actor
from leapp.tags import IPUWorkflowTag, ConfigurationCollectionPhaseTag
from leapp.models import ConfigurationSynchronization

import subprocess
import json


class AuthenticationConfigurationCollector(Actor):
    """
    Keep authentication configuration the same after migration. This is collection phase.
    """

    name = 'authentication_configuration_collector'
    consumes = ()
    produces = (ConfigurationSynchronization, )
    tags = (IPUWorkflowTag, ConfigurationCollectionPhaseTag, )

    def process(self):
        PermitRootLogin = subprocess.check_output('cat /etc/ssh/sshd_config | grep "^PermitRootLogin" || echo "DefaultValue"', shell=True)
        PasswordAuthentication = subprocess.check_output('cat /etc/ssh/sshd_config | egrep "^PasswordAuthentication" || echo "DefaultValue"', shell=True)
        PermitRootLogin = str(PermitRootLogin).strip()
        PasswordAuthentication = str(PasswordAuthentication).strip()

        self.produce(ConfigurationSynchronization(sshd_auth_configuration=json.dumps({"PermitRootLogin": PermitRootLogin, "PasswordAuthentication": PasswordAuthentication, })))
