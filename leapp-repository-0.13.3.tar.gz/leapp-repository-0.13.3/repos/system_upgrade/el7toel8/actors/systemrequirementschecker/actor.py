from leapp.actors import Actor
from leapp import tags
from leapp.libraries.actor import systemchecker

from leapp.exceptions import SystemEnvironmentCheckError, FailureInSystemEnvironmentCheckError
import sys
import traceback


class SystemRequirementsChecker(Actor):
    """
    No documentation has been provided for the system_requirements_checker actor.
    """

    name = 'system_requirements_checker'
    consumes = ()
    produces = ()
    tags = (tags.FactsPhaseTag, tags.IPUWorkflowTag, )

    def process(self):
        sc = systemchecker.SystemChecker()
        vm_info = sc.virtual_memory()
        partition = sc.partition_size_from_directory("/var/lib/leapp/")

        try:
            assert partition['free'] >= 4 * 1024 * 1024 * 1024 and vm_info['free'] >=  600 * 1024 * 1024, "To ensure the migration, this machine must have 4G free space on disk and 600M RAM available."
            assert sc.initd_is_symlink(), "It is crucial that /etc/init.d be a symlink to rc.d/init.d by default."
        except AssertionError as e:
            raise SystemEnvironmentCheckError(message=e.message, traceback=''.join(traceback.format_exception(*sys.exc_info())))
        except Exception as e:
            raise FailureInSystemEnvironmentCheckError(message="Exception raised in system requirements check.", traceback=''.join(traceback.format_exception(*sys.exc_info())))
