import subprocess
import os
import sys
import psutil


class SystemChecker(object):
    def partition_size_from_directory(self, directory):
        statvfs = os.statvfs(directory)
        return {
            "free": statvfs.f_frsize * statvfs.f_bfree,
            "total": statvfs.f_frsize * statvfs.f_blocks,
            "blocks": statvfs.f_blocks,
            "freeblocks": statvfs.f_bfree,
            "blocksize": statvfs.f_frsize,
        }

    def virtual_memory(self):
        mem_info = psutil.virtual_memory()
        return {
            "free": mem_info.available,
            "total": mem_info.total,
        }

    def is_symlink(self, directory):
        return os.path.islink(directory)

    def initd_is_symlink(self, initd_directory="/etc/init.d"):
        is_symlink = self.is_symlink(initd_directory)
        if not is_symlink:
            return False
        link_path = os.readlink(initd_directory)
        return link_path == "rc.d/init.d" or link_path == "/etc/rc.d/init.d"
