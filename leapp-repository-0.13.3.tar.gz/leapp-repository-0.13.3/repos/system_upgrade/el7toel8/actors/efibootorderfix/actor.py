import os
import subprocess

from leapp.actors import Actor
from leapp import reporting
from leapp.tags import ChecksPhaseTag, IPUWorkflowTag
from leapp.models import FirmwareFacts
from leapp.libraries.stdlib import api
from leapp.dialogs import Dialog
from leapp.dialogs.components import BooleanComponent

class EfiCheckBoot(Actor):
    """
    Adjust EFI boot entry for first reboot
    """

    name = 'efi_check_boot'
    consumes = (FirmwareFacts,)
    produces = (reporting.Report,)
    tags = (ChecksPhaseTag, IPUWorkflowTag)

    dialogs = (
        Dialog(
            scope='install_efibootmgr',
            reason='Confirmation',
            components=(
                BooleanComponent(
                    key='confirm',
                    label='Install efibootmgr? '
                          'If no, the upgrade process will be interrupted.',
                    description='efibootmgr package is required on EFI systems.',
                    default=True,
                    reason='efibootmgr is required so that we can set proper boot options in between restarts. '
                ),
            )
        ),
    )

    def process(self):
        is_system_efi = False
        has_efibootmgr = os.path.exists('/sbin/efibootmgr')
        for fact in self.consume(FirmwareFacts):
            if fact.firmware == 'efi':
                is_system_efi = True
                break

        if is_system_efi and not has_efibootmgr:
            command = "yum install -y efibootmgr"
            answer = self.get_answers(self.dialogs[0])
            if answer.get('confirm') == True:
                try:
                    subprocess.check_output(command, shell=True, stderr=subprocess.STDOUT)
                except subprocess.CalledProcessError as e:
                    api.current_logger().error('install efibootmgr failed: {}'.format(e))
                else:
                    api.current_logger().info('install efibootmgr succeeded: {}'.format(command))
                    return

            reporting.create_report([
                reporting.Title('efibootmgr package is required on EFI systems'),
                reporting.Summary(
                    'efibootmgr is required so that we can can set proper boot options in between restarts'
                ),
                reporting.Remediation(commands=[[command]]),
                reporting.RelatedResource('package', 'efibootmgr'),
                reporting.Flags([reporting.Flags.INHIBITOR]),
                reporting.Severity(reporting.Severity.HIGH),
                reporting.Tags([reporting.Tags.BOOT])
            ])
