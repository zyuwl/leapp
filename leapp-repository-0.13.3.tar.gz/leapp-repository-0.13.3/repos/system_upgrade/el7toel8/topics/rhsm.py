from leapp.topics import Topic


class RHSMTopic(Topic):
    name = 'rhsm'
