from leapp.topics import Topic


class SystemFactsTopic(Topic):
    name = 'system_facts'
