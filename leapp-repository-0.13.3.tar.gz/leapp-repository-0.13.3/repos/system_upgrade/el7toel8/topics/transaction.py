from leapp.topics import Topic


class TransactionTopic(Topic):
    name = 'transaction'
