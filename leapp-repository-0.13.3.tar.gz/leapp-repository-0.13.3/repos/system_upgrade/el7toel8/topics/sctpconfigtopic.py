from leapp.topics import Topic


class SCTPConfigTopic(Topic):
    name = 'sctp_config_topic'
