from leapp.topics import Topic


class TargetUserspaceTopic(Topic):
    name = 'target_userspace'
