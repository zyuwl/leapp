from leapp.topics import Topic


class ConfigurationSynchronizationTopic(Topic):
    name = 'configuration_synchronization'
