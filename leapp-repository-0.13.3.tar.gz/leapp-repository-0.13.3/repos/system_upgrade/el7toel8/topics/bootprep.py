from leapp.topics import Topic


class BootPrepTopic(Topic):
    name = 'boot_prep'
